package com.ob.dao;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;


public interface IOnlineBankingDao {

	abstract void customerSignUp(CustomerSignUp obs);

	abstract void createAccount(NewAccount newcustomer);

	abstract void updateLoginPassword(String loginPassword);

	abstract int customerAccountBalance(int accountId);

}
