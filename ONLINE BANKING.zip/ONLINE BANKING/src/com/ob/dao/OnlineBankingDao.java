package com.ob.dao;


import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;


public class OnlineBankingDao implements IOnlineBankingDao{
	
	
	public void customerSignUp(CustomerSignUp obs) {
		
		
		
		
	}

	@Override
	public void createAccount(NewAccount newcustomer) {
		
		
	}

	@Override
	public void updateLoginPassword(String loginPassword) {
		
		
	}

	@Override
	public int customerAccountBalance(int accountId) {
		/*  retrive customer account balance     */
		return 0;
	}

}
