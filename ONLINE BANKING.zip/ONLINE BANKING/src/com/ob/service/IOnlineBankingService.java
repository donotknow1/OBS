package com.ob.service;

import java.util.List;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;

public interface IOnlineBankingService {

	abstract void validateUsername(String username);
	abstract void validatePassword(String password);
	abstract void customerSignUp(CustomerSignUp csu);
	abstract void createAccount(NewAccount newcustomer);
	abstract void updateLoginPassword(int userid,String loginPassword);
	abstract int customerAccountBalance(int accountId);
	abstract int CustomerAccountId();
	abstract void Request(int acc_id, String description);
	abstract int retriveAccountId(String custusername, String custpassword);
	abstract List<ServiceTracker> retrieveServiceTrackerByAccountId(int accountId);

}
