package com.ob.service;

import com.ob.dao.IOnlineBankingDao;
import com.ob.dao.OnlineBankingDao;
import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;

public class OnlineBankingService implements IOnlineBankingService{
	
	static IOnlineBankingDao daoobj;
	
	
	
	public OnlineBankingService() {
		daoobj=new OnlineBankingDao();
	}
	public void validateUsername(String username) {
		
	}
	public void validatePassword(String password) {
		
	}
	public void customerSignUp(CustomerSignUp  obs) {
		daoobj.customerSignUp(obs);
		
	}
	@Override
	public void createAccount(NewAccount newcustomer) {
		daoobj.createAccount(newcustomer);
		
	}
	public void updateLoginPassword(int userid,String loginPassword) {
		
		daoobj.updateLoginPassword(userid,loginPassword);
	}
	@Override
	public int customerAccountBalance(int accountId) {
		
		return daoobj.customerAccountBalance(accountId);
	}
	@Override
	public int CustomerAccountId() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void Request(int acc_id, String description) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int retriveAccountId(String custusername, String custpassword) {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
