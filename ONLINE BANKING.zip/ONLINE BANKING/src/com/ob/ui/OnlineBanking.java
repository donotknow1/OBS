package com.ob.ui;

import java.util.List;
import java.util.Scanner;

import com.ob.dtobean.CustomerSignUp;
import com.ob.dtobean.NewAccount;
import com.ob.dtobean.ServiceTracker;
import com.ob.service.IOnlineBankingService;
import com.ob.service.OnlineBankingService;

public class OnlineBanking {
	 static Scanner sc=null;
	 static IOnlineBankingService serobj;
	 static CustomerSignUp csu;
	
	public OnlineBanking() {
		serobj=new OnlineBankingService();
	}
	
	/*  main program  */
	public static void main(String[] args) {
		
		sc=new Scanner(System.in);
		
		System.out.println("WELCOME TO THE ONLINE BANKING");
		System.out.println("PRESS  .....");
		System.out.println("1  ------>  CUSTOMER LOGIN  ");
		System.out.println("2  ------>  ADMINISTRATION LOGIN  ");
		
		int option=sc.nextInt();
		switch (option) {
		case 1:
			System.out.println("WELCOME TO CUSTOMER LOGIN");
			
			customerLoginPage();
			break;

		case 2:
			System.out.println("WELCOME TO ADMINISTRATION LOGIN");
			
			administrationLoginPage();
			
			break;
			
        default:
            System.out.println("EXIT");
			
			System.exit(0);
			break;
		}
		
	}
	
	/* customer   sign in and sign up  */
	
	public static void customerLoginPage() {
		
		System.out.println("PRESS 1 FOR SIGN IN AND 2 FOR SIGN UP");
		int custsignin=sc.nextInt();
		switch (custsignin) {
		case 1:
			
		     System.out.println("ENTER YOUR USERNAME");
		     String custusername=sc.nextLine();
		     serobj.validateUsername(custusername);
		
		     System.out.println("ENTER YOUR PASSWORD");
		     String custpassword=sc.nextLine();
		     serobj.validatePassword(custpassword);
		     
		     /* retrive customer account id using username and password */
		/* pass it in customer Login below */
		     int accountId=serobj.retriveAccountId(custusername,custpassword);
		     
		     
		     customerLogin(accountId);
		
		  break;
		
		case 2:
		
		     System.out.println("SIGN UP");
		     String custsignup=sc.nextLine();
		     
		     customerSignUp();
		
		  break;
		
		default:
			System.out.println("PLEASE ENTER CORRECT OPTION");
			break;
		}
		
		
	}
	public static void administrationLoginPage() {
		
		System.out.println("ENTER YOUR USERNAME");
		String adminusername=sc.nextLine();
		serobj.validateUsername(adminusername);
		
		System.out.println("ENTER YOUR PASSWORD");
		String adminpassword=sc.nextLine();
		serobj.validatePassword(adminpassword);
		
		administrationLogin();
	}
	
	public static void customerLogin(int accountId) {
		
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1  --->  ACCOUNT BALANCE");
		System.out.println("2  --->  MINI/DETAILED STATEMENTS");
		System.out.println("3  --->  ADDRESS CHANGE REQUEST");
		System.out.println("4  --->  MOBILE NO. CHANGE REQUEST");
		System.out.println("5  --->  CHEQUE BOOK REQUEST");
		System.out.println("6  --->  SERVICE REQUEST TRACKER");
		System.out.println("7  --->  FUND TRANSFER");
		System.out.println("8  --->  CHANGE PASSWORD");
		
		int custoption=sc.nextInt();
		
		String description=null;
		switch (custoption) {
		
		case 1:
		    int acc_bal=serobj.customerAccountBalance(accountId);
			System.out.println("YOUR ACCOUNT BALANCE  :  "+acc_bal);
			break;
			
        case 2:
			
			break;
			
        case 3:
        	System.out.println("ENTER YOUR NEW ADDRESS");
        	description=sc.next();
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	        break;
	        
        case 4:
        	System.out.println("ENTER YOUR NEW MOBILE NUMBER");
        	description=sc.next();
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 5:
        	acc_id=serobj.CustomerAccountId();
        	description="NEW CHEQUEBOOK";
        	serobj.Request(accountId,description);
	        System.out.println("REQUEST PROCESSED");
	
	        break;
	        
        case 6:
        	
        	List<ServiceTracker> servicetracker=null;
			
				servicetracker = serobj.retrieveServiceTrackerByAccountId(accountId);
		
			
			for(ServiceTracker st:servicetracker)
			{
			System.out.println(st);	
			}
	 
	        break;
	        
        case 7:
        	
       	 
	        break;
	     
        
        case 8:
        	System.out.println("CREATE A NEW PASSWORD FOR USERLOGIN");
        	String loginPassword=sc.next();
        	serobj.updateLoginPassword(accountId,loginPassword);
        	/*    provide  status       */
	
	        break;
        
		default:
			break;
		}
		
		
	}
	public static void administrationLogin() {
		System.out.println("PLEASE SELECT THE SERVICES");
		System.out.println("1  --->  CREATE NEW ACCOUNT");
		System.out.println("2  --->  VIEW TRANSACTION");
		int adminoption=sc.nextInt();
		switch (adminoption) {
		case 1:
			NewAccount newcustomer=new NewAccount();
			
			System.out.println("PLEASE ENTER YOUR DETAILS");
			System.out.println("ENTER YOUR NAME ");
			String name=sc.nextLine();
			newcustomer.setCustomerName(name);
			
			System.out.println("ENTER ADDRESS DETAILS");
			String address=sc.nextLine();
			newcustomer.setCustomerAddress(address);
			
			System.out.println("ENTER MOBILE NUMBER");
			String mob_num=sc.nextLine();
			newcustomer.setCustomerMobNum(mob_num);
			
			System.out.println("ENTER EMAIL ID");
			String email=sc.nextLine();
			newcustomer.setCustomerEmail(email);
			
			System.out.println("ENTER ACCOUNT TYPE");
			String acc_type=sc.nextLine();
			newcustomer.setAccountType(acc_type);
			
			int id=generateAccountId();
			System.out.println("YOUR ACCOUNT ID GENERATED : "+id);
			newcustomer.setAccountId(id);
			
			System.out.println("OPENING BALANCE");
			String opening_bal=sc.nextLine();
			newcustomer.setAccountBalance(opening_bal);
			
			serobj.createAccount(newcustomer);
			
			System.out.println("WELCOME TO ****** BANK");
			
			break;
        
        case 2:
        	System.out.println("ENTER THE ACCOUNT NUMBER");
        	String acc_num=sc.nextLine();
        	System.out.println("PERIOID              ");
			
			break;
		default:
			break;
		}
		
	}
	
	
	public static void customerSignUp() {
		
		 csu=new CustomerSignUp();
		
		System.out.println("ENTER THE ACCOUNT ID");
		int accountId=sc.nextInt();
		csu.setAccountId(accountId);
		
		System.out.println("CREATE USER NAME");
		int userId=sc.nextInt();
		csu.setUserId(userId);
		
		System.out.println("CREATE PASSWORD");
		String loginPassword=sc.next();
		csu.setLoginPassword(loginPassword);
		
		System.out.println("SECRET QUESTION --> WHEN DO YOU GET HIGH ?");
		String secretQuestion=sc.next();
		csu.setSecretQuestion(secretQuestion);
		
		System.out.println("CREATE TRANSACTION PASSWORD");
		String transactionPassword=sc.next();
		csu.setTransactionPassword(transactionPassword);
		
		System.out.println("CREATE LOCK STATUS ****************************");
		String lockStatus=sc.next();
		csu.setLockStatus(lockStatus);
		
		serobj.customerSignUp(csu);
		 
	}
	public static int generateAccountId() {
		int accountId=(int)(Math.random()*1000000000);
		return accountId;
	}

}
